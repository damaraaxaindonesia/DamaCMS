
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_web_site_widget`
--

CREATE TABLE `dam_core_ncc_web_site_widget` (
  `Id` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `LayoutName` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `ModuleName` longtext,
  `Name` longtext,
  `Status` int(11) NOT NULL,
  `ThemeId` longtext,
  `VersionNumber` int(11) NOT NULL,
  `WebSiteId` bigint(20) DEFAULT NULL,
  `WidgetConfigJson` longtext,
  `WidgetData` longtext,
  `WidgetId` longtext,
  `WidgetOrder` int(11) NOT NULL,
  `Zone` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_web_site_widget`
--

INSERT INTO `dam_core_ncc_web_site_widget` (`Id`, `CreateBy`, `CreationDate`, `LayoutName`, `Metadata`, `ModificationDate`, `ModifyBy`, `ModuleName`, `Name`, `Status`, `ThemeId`, `VersionNumber`, `WebSiteId`, `WidgetConfigJson`, `WidgetData`, `WidgetId`, `WidgetOrder`, `Zone`) VALUES
(1, 1, '2018-09-07 17:35:11.080637', 'HomeLayout', '', '2018-09-07 17:35:11.080637', 1, 'Core.Cms', '', 0, 'NccSeventeen', 1, 1, '', '', 'Core.Cms_Core.Cms.Widgets.CmsSearchWidget', 1, 'TopBar'),
(2, 1, '2018-09-09 11:58:14.064605', 'SiteLayout', '', '2018-09-09 11:58:14.064605', 1, 'Core.Cms', '', 0, 'DefaultTheme', 1, 1, '', '', 'Core.Cms_Core.Cms.Widgets.CmsSearchWidget', 1, 'Footer');
