
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_widget_section`
--

CREATE TABLE `dam_core_ncc_widget_section` (
  `Id` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Dependencies` longtext,
  `Description` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `NetCoreCMSVersion` longtext,
  `SortName` longtext,
  `Status` int(11) NOT NULL,
  `Title` longtext,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
