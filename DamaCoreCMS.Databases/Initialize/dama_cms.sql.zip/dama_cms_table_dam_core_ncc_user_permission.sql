
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_user_permission`
--

CREATE TABLE `dam_core_ncc_user_permission` (
  `UserId` bigint(20) NOT NULL,
  `PermissionId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_user_permission`
--

INSERT INTO `dam_core_ncc_user_permission` (`UserId`, `PermissionId`) VALUES
(1, 1);
