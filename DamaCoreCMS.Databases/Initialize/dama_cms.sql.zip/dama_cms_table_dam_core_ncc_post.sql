
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_post`
--

CREATE TABLE `dam_core_ncc_post` (
  `Id` bigint(20) NOT NULL,
  `AllowComment` bit(1) NOT NULL,
  `AuthorId` bigint(20) DEFAULT NULL,
  `CommentCount` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `IsFeatured` bit(1) NOT NULL,
  `IsStiky` bit(1) NOT NULL,
  `Layout` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `ParentId` bigint(20) DEFAULT NULL,
  `PostStatus` int(11) NOT NULL,
  `PostType` int(11) NOT NULL,
  `PublishDate` datetime(6) NOT NULL,
  `RelatedPosts` longtext,
  `Status` int(11) NOT NULL,
  `ThumImage` longtext,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_post`
--

INSERT INTO `dam_core_ncc_post` (`Id`, `AllowComment`, `AuthorId`, `CommentCount`, `CreateBy`, `CreationDate`, `IsFeatured`, `IsStiky`, `Layout`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `ParentId`, `PostStatus`, `PostType`, `PublishDate`, `RelatedPosts`, `Status`, `ThumImage`, `VersionNumber`) VALUES
(1, b'1', NULL, 0, 0, '2018-09-07 15:34:45.381105', b'0', b'0', 'SiteLayout', 'DEMODATA', '2018-09-07 15:34:46.045313', 0, 'Sample Post ', NULL, 2, 0, '2018-09-07 15:34:45.377909', NULL, 0, '/media/Images/2017/06/image-slider-2.jpg', 2);
