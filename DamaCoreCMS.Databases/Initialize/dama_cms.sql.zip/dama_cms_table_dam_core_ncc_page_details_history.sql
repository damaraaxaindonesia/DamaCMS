
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_page_details_history`
--

CREATE TABLE `dam_core_ncc_page_details_history` (
  `Id` bigint(20) NOT NULL,
  `Content` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Language` longtext,
  `MetaDescription` longtext,
  `MetaKeyword` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `PageDetailsId` bigint(20) NOT NULL,
  `PageHistoryId` bigint(20) DEFAULT NULL,
  `Slug` longtext,
  `Status` int(11) NOT NULL,
  `Title` longtext,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
