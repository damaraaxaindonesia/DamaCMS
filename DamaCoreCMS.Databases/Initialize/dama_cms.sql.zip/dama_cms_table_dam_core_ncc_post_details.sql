
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_post_details`
--

CREATE TABLE `dam_core_ncc_post_details` (
  `Id` bigint(20) NOT NULL,
  `Content` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Language` longtext,
  `MetaDescription` longtext,
  `MetaKeyword` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `PostId` bigint(20) DEFAULT NULL,
  `Slug` longtext,
  `Status` int(11) NOT NULL,
  `Title` longtext,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_post_details`
--

INSERT INTO `dam_core_ncc_post_details` (`Id`, `Content`, `CreateBy`, `CreationDate`, `Language`, `MetaDescription`, `MetaKeyword`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `PostId`, `Slug`, `Status`, `Title`, `VersionNumber`) VALUES
(1, '<h1 style=\"text-align:center\">Sample Post </h1><hr />This is a sample post.', 0, '2018-09-07 15:34:45.379135', 'en', 'Sample Post  This is a sample post.', NULL, '', '2018-09-07 15:34:46.043752', 0, 'Sample-Post', 1, 'Sample-Post', 0, 'Sample Post ', 1),
(2, '<h1 style=\"text-align:center\">????? ????? </h1><hr />??? ???? ????? ??????', 0, '2018-09-07 15:34:45.380263', 'bn', '????? ?????  ??? ???? ????? ??????', NULL, '', '2018-09-07 15:34:46.043752', 0, '?????-?????', 1, '?????-?????', 0, '????? ????? ', 1);
