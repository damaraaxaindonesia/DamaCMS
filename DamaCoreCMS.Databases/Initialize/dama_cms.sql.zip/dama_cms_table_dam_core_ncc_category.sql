
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_category`
--

CREATE TABLE `dam_core_ncc_category` (
  `Id` bigint(20) NOT NULL,
  `CategoryImage` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `ParentId` bigint(20) DEFAULT NULL,
  `Status` int(11) NOT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_category`
--

INSERT INTO `dam_core_ncc_category` (`Id`, `CategoryImage`, `CreateBy`, `CreationDate`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `ParentId`, `Status`, `VersionNumber`) VALUES
(1, '/media/Images/2017/06/image-slider-0.jpg', 0, '2018-09-07 15:34:44.944402', 'DEMODATA', '2018-09-07 15:34:44.944402', 0, 'Sample Category ', NULL, 0, 1);
