
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_permission`
--

CREATE TABLE `dam_core_ncc_permission` (
  `Id` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Description` longtext,
  `Group` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `Rank` int(11) NOT NULL,
  `Status` int(11) NOT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_permission`
--

INSERT INTO `dam_core_ncc_permission` (`Id`, `CreateBy`, `CreationDate`, `Description`, `Group`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `Rank`, `Status`, `VersionNumber`) VALUES
(1, 0, '2018-09-07 15:34:42.015633', 'Permission for Administrative users.', 'NetCoreCMS', '', '2018-09-07 15:34:42.015633', 0, 'Administrator', 1, 0, 1),
(2, 0, '2018-09-07 15:34:42.146586', 'Permission for Managers.', 'NetCoreCMS', '', '2018-09-07 15:34:42.146586', 0, 'Manager', 2, 0, 1),
(3, 0, '2018-09-07 15:34:42.153275', 'Permission for Editor.', 'NetCoreCMS', '', '2018-09-07 15:34:42.153275', 0, 'Editor', 3, 0, 1),
(4, 0, '2018-09-07 15:34:42.154035', 'Permission for Authors.', 'NetCoreCMS', '', '2018-09-07 15:34:42.154035', 0, 'Author', 4, 0, 1),
(5, 0, '2018-09-07 15:34:42.154477', 'Permission for Contributor.', 'NetCoreCMS', '', '2018-09-07 15:34:42.154477', 0, 'Contributor', 5, 0, 1),
(6, 0, '2018-09-07 15:34:42.154899', 'Permission for Subscriber.', 'NetCoreCMS', '', '2018-09-07 15:34:42.154899', 0, 'Subscriber', 1000, 0, 1);
