
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_post_tag`
--

CREATE TABLE `dam_core_ncc_post_tag` (
  `PostId` bigint(20) NOT NULL,
  `TagId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
