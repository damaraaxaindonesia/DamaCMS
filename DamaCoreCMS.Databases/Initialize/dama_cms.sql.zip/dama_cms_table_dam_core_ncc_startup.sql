
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_startup`
--

CREATE TABLE `dam_core_ncc_startup` (
  `Id` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `PermissionId` bigint(20) DEFAULT NULL,
  `RoleId` bigint(20) NOT NULL,
  `StartupFor` int(11) NOT NULL,
  `StartupType` int(11) NOT NULL,
  `StartupUrl` longtext,
  `Status` int(11) NOT NULL,
  `UserId` bigint(20) NOT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
