
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_widget`
--

CREATE TABLE `dam_core_ncc_widget` (
  `Id` bigint(20) NOT NULL,
  `Content` longblob,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Dependencies` longtext,
  `Description` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `NccPluginsId` bigint(20) DEFAULT NULL,
  `NetCoreCMSVersion` longtext,
  `SortName` longtext,
  `Status` int(11) NOT NULL,
  `Title` longtext,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
