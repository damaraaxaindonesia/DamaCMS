
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_web_site`
--

CREATE TABLE `dam_core_ncc_web_site` (
  `Id` bigint(20) NOT NULL,
  `AdminPageSize` int(11) NOT NULL,
  `AllowRegistration` bit(1) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `DateFormat` longtext,
  `DomainName` longtext,
  `EmailAddress` longtext,
  `EnableCache` bit(1) NOT NULL DEFAULT b'0',
  `GoogleAnalyticsId` longtext,
  `IsMultiLangual` bit(1) NOT NULL,
  `IsShowFullPost` bit(1) NOT NULL,
  `Language` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `NewUserRole` longtext,
  `Status` int(11) NOT NULL,
  `TablePrefix` longtext,
  `TimeFormat` longtext,
  `TimeZone` longtext,
  `VersionNumber` int(11) NOT NULL,
  `WebSitePageSize` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_web_site`
--

INSERT INTO `dam_core_ncc_web_site` (`Id`, `AdminPageSize`, `AllowRegistration`, `CreateBy`, `CreationDate`, `DateFormat`, `DomainName`, `EmailAddress`, `EnableCache`, `GoogleAnalyticsId`, `IsMultiLangual`, `IsShowFullPost`, `Language`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `NewUserRole`, `Status`, `TablePrefix`, `TimeFormat`, `TimeZone`, `VersionNumber`, `WebSitePageSize`) VALUES
(1, 10, b'1', 0, '2018-09-07 15:34:44.113997', 'dd/MM/yyyy', NULL, 'admin@yourdomain.com', b'0', NULL, b'0', b'0', 'en', '', '2018-09-07 15:34:44.113997', 0, 'Damara', 'Subscriber', 0, 'dam_', 'hh:mm:ss', 'UTC_6', 1, 10);
