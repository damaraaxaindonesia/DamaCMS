
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_page`
--

CREATE TABLE `dam_core_ncc_page` (
  `Id` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Layout` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `PageOrder` int(11) NOT NULL,
  `PageStatus` int(11) NOT NULL,
  `PageType` int(11) NOT NULL,
  `ParentId` bigint(20) DEFAULT NULL,
  `PublishDate` datetime(6) NOT NULL,
  `Status` int(11) NOT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_page`
--

INSERT INTO `dam_core_ncc_page` (`Id`, `CreateBy`, `CreationDate`, `Layout`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `PageOrder`, `PageStatus`, `PageType`, `ParentId`, `PublishDate`, `Status`, `VersionNumber`) VALUES
(1, 0, '2018-09-07 15:34:44.311003', 'SiteLayout', 'DEMODATA', '2018-09-07 15:34:44.311003', 0, 'Sample Page ', 0, 2, 0, NULL, '2018-09-07 15:34:44.307105', 0, 1),
(2, 1, '2018-09-08 15:46:38.928474', 'FullWidthLayout', '', '2018-09-08 15:46:38.928474', 1, 'rere', 0, 2, 0, NULL, '2018-09-08 15:45:00.000000', 0, 1);
