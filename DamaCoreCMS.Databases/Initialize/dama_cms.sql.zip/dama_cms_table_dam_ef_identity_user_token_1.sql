
-- --------------------------------------------------------

--
-- Table structure for table `dam_ef_identity_user_token_1`
--

CREATE TABLE `dam_ef_identity_user_token_1` (
  `UserId` bigint(20) NOT NULL,
  `LoginProvider` varchar(127) NOT NULL,
  `Name` varchar(127) NOT NULL,
  `Value` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
