
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_user_role`
--

CREATE TABLE `dam_core_ncc_user_role` (
  `UserId` bigint(20) NOT NULL,
  `RoleId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_user_role`
--

INSERT INTO `dam_core_ncc_user_role` (`UserId`, `RoleId`) VALUES
(1, 1);
