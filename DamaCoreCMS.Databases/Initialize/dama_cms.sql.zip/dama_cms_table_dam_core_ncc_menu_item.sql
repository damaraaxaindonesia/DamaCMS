
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_menu_item`
--

CREATE TABLE `dam_core_ncc_menu_item` (
  `Id` bigint(20) NOT NULL,
  `Action` longtext,
  `Controller` longtext,
  `Area` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Data` longtext,
  `MenuActionType` int(11) NOT NULL,
  `MenuFor` int(11) NOT NULL,
  `MenuIconCls` longtext,
  `MenuOrder` int(11) NOT NULL,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Module` longtext,
  `Name` longtext,
  `NccMenuId` bigint(20) DEFAULT NULL,
  `NccMenuItemId` bigint(20) DEFAULT NULL,
  `NccMenuItemId1` bigint(20) DEFAULT NULL,
  `ParentId` bigint(20) DEFAULT NULL,
  `Position` int(11) NOT NULL,
  `Status` int(11) NOT NULL,
  `Target` longtext,
  `Url` longtext,
  `IsAnonymous` bit(1) NOT NULL DEFAULT b'0',
  `IsAllowAuthenticated` bit(1) NOT NULL DEFAULT b'0',
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_menu_item`
--

INSERT INTO `dam_core_ncc_menu_item` (`Id`, `Action`, `Controller`, `Area`, `CreateBy`, `CreationDate`, `Data`, `MenuActionType`, `MenuFor`, `MenuIconCls`, `MenuOrder`, `Metadata`, `ModificationDate`, `ModifyBy`, `Module`, `Name`, `NccMenuId`, `NccMenuItemId`, `NccMenuItemId1`, `ParentId`, `Position`, `Status`, `Target`, `Url`, `IsAnonymous`, `IsAllowAuthenticated`, `VersionNumber`) VALUES
(14, 'Index', 'CmsPage', '', 1, '2018-09-08 15:47:23.606115', '3', 1, 0, NULL, 5, '', '2018-09-08 15:47:23.606115', 1, NULL, 'atesr', NULL, NULL, NULL, NULL, 0, 0, '_self', '/rere', b'0', b'0', 1),
(18, '', '', '', 1, '2018-09-08 15:48:19.348656', '', 0, 0, NULL, 2, '', '2018-09-08 15:48:19.348656', 1, NULL, 'Blog Categories', NULL, NULL, NULL, NULL, 0, 0, '_self', '/Category', b'0', b'0', 1),
(26, 'Index', 'Home', '', 1, '2018-09-10 03:03:09.006772', '', 0, 0, NULL, 1, '', '2018-09-10 03:03:09.006773', 1, NULL, 'Home', NULL, NULL, NULL, NULL, 0, 0, '', '/CmsHome', b'0', b'0', 1),
(29, 'Index', 'Home', '', 1, '2018-09-10 03:03:19.329591', '', 0, 0, NULL, 1, '', '2018-09-10 03:03:19.329592', 1, NULL, 'Home', NULL, NULL, NULL, NULL, 0, 0, '', '/CmsHome', b'0', b'0', 1),
(30, 'Index', 'Home', '', 1, '2018-09-10 03:03:54.564314', '', 0, 0, NULL, 1, '', '2018-09-10 03:03:54.564314', 1, NULL, 'Home', 3, NULL, NULL, NULL, 0, 0, '', '/CmsHome', b'0', b'0', 1),
(31, 'Index', 'CmsPage', '', 1, '2018-09-10 03:03:54.564330', '3', 1, 0, NULL, 2, '', '2018-09-10 03:03:54.564330', 1, NULL, 'atesr', 3, NULL, NULL, NULL, 0, 0, '_self', '/rere', b'0', b'0', 1),
(32, 'Index', 'CmsPage', '', 1, '2018-09-10 03:03:54.564350', '1', 1, 0, NULL, 3, '', '2018-09-10 03:03:54.564350', 1, NULL, 'Sample Page ', 3, NULL, NULL, NULL, 0, 0, '_self', '/Sample-Page', b'0', b'0', 1);
