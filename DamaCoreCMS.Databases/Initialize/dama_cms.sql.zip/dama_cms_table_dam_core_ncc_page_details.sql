
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_page_details`
--

CREATE TABLE `dam_core_ncc_page_details` (
  `Id` bigint(20) NOT NULL,
  `Content` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Language` longtext,
  `MetaDescription` longtext,
  `MetaKeyword` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `PageId` bigint(20) DEFAULT NULL,
  `Slug` longtext,
  `Status` int(11) NOT NULL,
  `Title` longtext,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_page_details`
--

INSERT INTO `dam_core_ncc_page_details` (`Id`, `Content`, `CreateBy`, `CreationDate`, `Language`, `MetaDescription`, `MetaKeyword`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `PageId`, `Slug`, `Status`, `Title`, `VersionNumber`) VALUES
(1, '<h1 style=\"text-align:center\">Sample Page </h1><p>This is a sample page.</p>', 0, '2018-09-07 15:34:44.308109', 'en', 'Sample Page  This is a sample page.', NULL, '', '2018-09-07 15:34:44.308111', 0, 'Sample-Page', 1, 'Sample-Page', 0, 'Sample Page ', 1),
(2, '<h1 style=\"text-align:center\">????? ?????? </h1><p>??? ???? ????? ?????</p>', 0, '2018-09-07 15:34:44.309022', 'bn', '????? ??????  ??? ???? ????? ?????', NULL, '', '2018-09-07 15:34:44.309024', 0, '?????-??????', 1, '?????-??????', 0, '????? ?????? ', 1),
(3, '<div>vcvsdfsdfsdfsdfsdf</div>\r\n', 1, '2018-09-08 15:46:38.777154', 'en', 'vcvsdfsdfsdfsdfsdf\r\n', NULL, '', '2018-09-08 15:46:38.777155', 1, '', 2, 'rere', 0, 'atesr', 1);
