
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_plugins`
--

CREATE TABLE `dam_core_ncc_plugins` (
  `Id` bigint(20) NOT NULL,
  `AntiForgery` bit(1) NOT NULL,
  `Author` longtext,
  `Category` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Dependencies` longtext,
  `Description` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `NetCoreCMSVersion` longtext,
  `Path` longtext,
  `PluginsStatus` int(11) NOT NULL,
  `SortName` longtext,
  `Status` int(11) NOT NULL,
  `Version` longtext,
  `VersionNumber` int(11) NOT NULL,
  `Website` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
