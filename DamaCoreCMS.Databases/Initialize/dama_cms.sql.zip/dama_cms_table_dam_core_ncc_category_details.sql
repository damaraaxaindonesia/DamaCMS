
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_category_details`
--

CREATE TABLE `dam_core_ncc_category_details` (
  `Id` bigint(20) NOT NULL,
  `CategoryId` bigint(20) DEFAULT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Language` longtext,
  `MetaDescription` longtext,
  `MetaKeyword` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `Slug` longtext,
  `Status` int(11) NOT NULL,
  `Title` longtext,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_category_details`
--

INSERT INTO `dam_core_ncc_category_details` (`Id`, `CategoryId`, `CreateBy`, `CreationDate`, `Language`, `MetaDescription`, `MetaKeyword`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `Slug`, `Status`, `Title`, `VersionNumber`) VALUES
(1, 1, 0, '2018-09-07 15:34:44.943228', 'en', NULL, NULL, '', '2018-09-07 15:34:44.943229', 0, 'Sample-Category', 'Sample-Category', 0, 'Sample Category ', 1),
(2, 1, 0, '2018-09-07 15:34:44.943725', 'bn', NULL, NULL, '', '2018-09-07 15:34:44.943726', 0, '?????-?????????', '?????-?????????', 0, '????? ????????? ', 1);
