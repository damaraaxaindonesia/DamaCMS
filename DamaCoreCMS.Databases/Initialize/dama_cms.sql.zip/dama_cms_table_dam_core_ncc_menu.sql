
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_menu`
--

CREATE TABLE `dam_core_ncc_menu` (
  `Id` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `MenuIconCls` longtext,
  `MenuLanguage` longtext,
  `MenuOrder` int(11) NOT NULL,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `Position` longtext,
  `Status` int(11) NOT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_menu`
--

INSERT INTO `dam_core_ncc_menu` (`Id`, `CreateBy`, `CreationDate`, `MenuIconCls`, `MenuLanguage`, `MenuOrder`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `Position`, `Status`, `VersionNumber`) VALUES
(3, 1, '2018-09-10 03:03:54.567956', NULL, '', 1, '', '2018-09-10 03:03:54.567956', 1, 'qwer', 'Navigation', 0, 1);
