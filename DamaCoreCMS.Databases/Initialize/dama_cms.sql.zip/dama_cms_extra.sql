
--
-- Indexes for dumped tables
--

--
-- Indexes for table `dam_core_ncc_category`
--
ALTER TABLE `dam_core_ncc_category`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_category_ParentId` (`ParentId`);

--
-- Indexes for table `dam_core_ncc_category_details`
--
ALTER TABLE `dam_core_ncc_category_details`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_category_details_CategoryId` (`CategoryId`);

--
-- Indexes for table `dam_core_ncc_comment`
--
ALTER TABLE `dam_core_ncc_comment`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_comment_AuthorId` (`AuthorId`),
  ADD KEY `IX_dam_core_ncc_comment_PostId` (`PostId`);

--
-- Indexes for table `dam_core_ncc_menu`
--
ALTER TABLE `dam_core_ncc_menu`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_core_ncc_menu_item`
--
ALTER TABLE `dam_core_ncc_menu_item`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_menu_item_NccMenuId` (`NccMenuId`),
  ADD KEY `IX_dam_core_ncc_menu_item_NccMenuItemId` (`NccMenuItemId`),
  ADD KEY `IX_dam_core_ncc_menu_item_NccMenuItemId1` (`NccMenuItemId1`),
  ADD KEY `IX_dam_core_ncc_menu_item_ParentId` (`ParentId`);

--
-- Indexes for table `dam_core_ncc_module`
--
ALTER TABLE `dam_core_ncc_module`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_core_ncc_module_dependency`
--
ALTER TABLE `dam_core_ncc_module_dependency`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_module_dependency_NccModuleId` (`NccModuleId`);

--
-- Indexes for table `dam_core_ncc_page`
--
ALTER TABLE `dam_core_ncc_page`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_page_ParentId` (`ParentId`);

--
-- Indexes for table `dam_core_ncc_page_details`
--
ALTER TABLE `dam_core_ncc_page_details`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_page_details_PageId` (`PageId`);

--
-- Indexes for table `dam_core_ncc_page_details_history`
--
ALTER TABLE `dam_core_ncc_page_details_history`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_page_details_history_PageHistoryId` (`PageHistoryId`);

--
-- Indexes for table `dam_core_ncc_page_history`
--
ALTER TABLE `dam_core_ncc_page_history`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_page_history_ParentId` (`ParentId`);

--
-- Indexes for table `dam_core_ncc_permission`
--
ALTER TABLE `dam_core_ncc_permission`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_core_ncc_permission_details`
--
ALTER TABLE `dam_core_ncc_permission_details`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_permission_details_ExtraAllowUserId` (`ExtraAllowUserId`),
  ADD KEY `IX_dam_core_ncc_permission_details_ExtraDenyUserId` (`ExtraDenyUserId`),
  ADD KEY `IX_dam_core_ncc_permission_details_PermissionId` (`PermissionId`);

--
-- Indexes for table `dam_core_ncc_plugins`
--
ALTER TABLE `dam_core_ncc_plugins`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_core_ncc_post`
--
ALTER TABLE `dam_core_ncc_post`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_post_AuthorId` (`AuthorId`),
  ADD KEY `IX_dam_core_ncc_post_ParentId` (`ParentId`);

--
-- Indexes for table `dam_core_ncc_post_category`
--
ALTER TABLE `dam_core_ncc_post_category`
  ADD PRIMARY KEY (`PostId`,`CategoryId`),
  ADD KEY `IX_dam_core_ncc_post_category_CategoryId` (`CategoryId`);

--
-- Indexes for table `dam_core_ncc_post_details`
--
ALTER TABLE `dam_core_ncc_post_details`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_post_details_PostId` (`PostId`);

--
-- Indexes for table `dam_core_ncc_post_tag`
--
ALTER TABLE `dam_core_ncc_post_tag`
  ADD PRIMARY KEY (`PostId`,`TagId`),
  ADD KEY `IX_dam_core_ncc_post_tag_TagId` (`TagId`);

--
-- Indexes for table `dam_core_ncc_role`
--
ALTER TABLE `dam_core_ncc_role`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `IX_dam_core_ncc_role_RoleNameIndex` (`NormalizedName`);

--
-- Indexes for table `dam_core_ncc_schedule_task_history`
--
ALTER TABLE `dam_core_ncc_schedule_task_history`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_core_ncc_settings`
--
ALTER TABLE `dam_core_ncc_settings`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_core_ncc_startup`
--
ALTER TABLE `dam_core_ncc_startup`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_startup_PermissionId` (`PermissionId`);

--
-- Indexes for table `dam_core_ncc_tag`
--
ALTER TABLE `dam_core_ncc_tag`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_core_ncc_user`
--
ALTER TABLE `dam_core_ncc_user`
  ADD PRIMARY KEY (`Id`),
  ADD UNIQUE KEY `IX_dam_core_ncc_user_UserNameIndex` (`NormalizedUserName`),
  ADD KEY `IX_dam_core_ncc_user_EmailIndex` (`NormalizedEmail`);

--
-- Indexes for table `dam_core_ncc_user_permission`
--
ALTER TABLE `dam_core_ncc_user_permission`
  ADD PRIMARY KEY (`UserId`,`PermissionId`),
  ADD KEY `IX_dam_core_ncc_user_permission_PermissionId` (`PermissionId`);

--
-- Indexes for table `dam_core_ncc_user_role`
--
ALTER TABLE `dam_core_ncc_user_role`
  ADD PRIMARY KEY (`UserId`,`RoleId`),
  ADD KEY `IX_dam_core_ncc_user_role_RoleId` (`RoleId`);

--
-- Indexes for table `dam_core_ncc_web_site`
--
ALTER TABLE `dam_core_ncc_web_site`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_core_ncc_web_site_info`
--
ALTER TABLE `dam_core_ncc_web_site_info`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_web_site_info_NccWebSiteId` (`NccWebSiteId`);

--
-- Indexes for table `dam_core_ncc_web_site_widget`
--
ALTER TABLE `dam_core_ncc_web_site_widget`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_web_site_widget_WebSiteId` (`WebSiteId`);

--
-- Indexes for table `dam_core_ncc_widget`
--
ALTER TABLE `dam_core_ncc_widget`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_core_ncc_widget_NccPluginsId` (`NccPluginsId`);

--
-- Indexes for table `dam_core_ncc_widget_section`
--
ALTER TABLE `dam_core_ncc_widget_section`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `dam_ef_identity_role_claim_1`
--
ALTER TABLE `dam_ef_identity_role_claim_1`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_ef_identity_role_claim_1_RoleId` (`RoleId`);

--
-- Indexes for table `dam_ef_identity_user_claim_1`
--
ALTER TABLE `dam_ef_identity_user_claim_1`
  ADD PRIMARY KEY (`Id`),
  ADD KEY `IX_dam_ef_identity_user_claim_1_NccUserId` (`NccUserId`),
  ADD KEY `IX_dam_ef_identity_user_claim_1_UserId` (`UserId`);

--
-- Indexes for table `dam_ef_identity_user_login_1`
--
ALTER TABLE `dam_ef_identity_user_login_1`
  ADD PRIMARY KEY (`LoginProvider`,`ProviderKey`),
  ADD KEY `IX_dam_ef_identity_user_login_1_NccUserId` (`NccUserId`),
  ADD KEY `IX_dam_ef_identity_user_login_1_UserId` (`UserId`);

--
-- Indexes for table `dam_ef_identity_user_token_1`
--
ALTER TABLE `dam_ef_identity_user_token_1`
  ADD PRIMARY KEY (`UserId`,`LoginProvider`,`Name`);

--
-- Indexes for table `dam_ef_migration_history`
--
ALTER TABLE `dam_ef_migration_history`
  ADD PRIMARY KEY (`MigrationId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `dam_core_ncc_category`
--
ALTER TABLE `dam_core_ncc_category`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dam_core_ncc_category_details`
--
ALTER TABLE `dam_core_ncc_category_details`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dam_core_ncc_comment`
--
ALTER TABLE `dam_core_ncc_comment`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dam_core_ncc_menu`
--
ALTER TABLE `dam_core_ncc_menu`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dam_core_ncc_menu_item`
--
ALTER TABLE `dam_core_ncc_menu_item`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `dam_core_ncc_module`
--
ALTER TABLE `dam_core_ncc_module`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `dam_core_ncc_module_dependency`
--
ALTER TABLE `dam_core_ncc_module_dependency`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_page`
--
ALTER TABLE `dam_core_ncc_page`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dam_core_ncc_page_details`
--
ALTER TABLE `dam_core_ncc_page_details`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `dam_core_ncc_page_details_history`
--
ALTER TABLE `dam_core_ncc_page_details_history`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_page_history`
--
ALTER TABLE `dam_core_ncc_page_history`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_permission`
--
ALTER TABLE `dam_core_ncc_permission`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `dam_core_ncc_permission_details`
--
ALTER TABLE `dam_core_ncc_permission_details`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `dam_core_ncc_plugins`
--
ALTER TABLE `dam_core_ncc_plugins`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_post`
--
ALTER TABLE `dam_core_ncc_post`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dam_core_ncc_post_details`
--
ALTER TABLE `dam_core_ncc_post_details`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dam_core_ncc_role`
--
ALTER TABLE `dam_core_ncc_role`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dam_core_ncc_schedule_task_history`
--
ALTER TABLE `dam_core_ncc_schedule_task_history`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_settings`
--
ALTER TABLE `dam_core_ncc_settings`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_startup`
--
ALTER TABLE `dam_core_ncc_startup`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_tag`
--
ALTER TABLE `dam_core_ncc_tag`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_user`
--
ALTER TABLE `dam_core_ncc_user`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dam_core_ncc_web_site`
--
ALTER TABLE `dam_core_ncc_web_site`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `dam_core_ncc_web_site_info`
--
ALTER TABLE `dam_core_ncc_web_site_info`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dam_core_ncc_web_site_widget`
--
ALTER TABLE `dam_core_ncc_web_site_widget`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `dam_core_ncc_widget`
--
ALTER TABLE `dam_core_ncc_widget`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_core_ncc_widget_section`
--
ALTER TABLE `dam_core_ncc_widget_section`
  MODIFY `Id` bigint(20) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_ef_identity_role_claim_1`
--
ALTER TABLE `dam_ef_identity_role_claim_1`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `dam_ef_identity_user_claim_1`
--
ALTER TABLE `dam_ef_identity_user_claim_1`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `dam_core_ncc_category`
--
ALTER TABLE `dam_core_ncc_category`
  ADD CONSTRAINT `FK_dam_core_ncc_category_dam_core_ncc_category_ParentId` FOREIGN KEY (`ParentId`) REFERENCES `dam_core_ncc_category` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_category_details`
--
ALTER TABLE `dam_core_ncc_category_details`
  ADD CONSTRAINT `FK_dam_core_ncc_category_details_dam_core_ncc_category_details_C` FOREIGN KEY (`CategoryId`) REFERENCES `dam_core_ncc_category_details` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_comment`
--
ALTER TABLE `dam_core_ncc_comment`
  ADD CONSTRAINT `FK_dam_core_ncc_comment_dam_core_ncc_post_PostId` FOREIGN KEY (`PostId`) REFERENCES `dam_core_ncc_post` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_dam_core_ncc_comment_dam_core_ncc_user_AuthorId` FOREIGN KEY (`AuthorId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_menu_item`
--
ALTER TABLE `dam_core_ncc_menu_item`
  ADD CONSTRAINT `FK_dam_core_ncc_menu_item_dam_core_ncc_menu_NccMenuId` FOREIGN KEY (`NccMenuId`) REFERENCES `dam_core_ncc_menu` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_dam_core_ncc_menu_item_dam_core_ncc_menu_item_NMIId` FOREIGN KEY (`NccMenuItemId`) REFERENCES `dam_core_ncc_menu_item` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_dam_core_ncc_menu_item_dam_core_ncc_menu_item_NMItemId1` FOREIGN KEY (`NccMenuItemId1`) REFERENCES `dam_core_ncc_menu_item` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_dam_core_ncc_menu_item_dam_core_ncc_menu_item_ParentId` FOREIGN KEY (`ParentId`) REFERENCES `dam_core_ncc_menu_item` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_module_dependency`
--
ALTER TABLE `dam_core_ncc_module_dependency`
  ADD CONSTRAINT `FK_dam_core_ncc_module_dependency_dam_core_ncc_module_NccModuleI` FOREIGN KEY (`NccModuleId`) REFERENCES `dam_core_ncc_module` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_page`
--
ALTER TABLE `dam_core_ncc_page`
  ADD CONSTRAINT `FK_dam_core_ncc_page_dam_core_ncc_page_ParentId` FOREIGN KEY (`ParentId`) REFERENCES `dam_core_ncc_page` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_page_details`
--
ALTER TABLE `dam_core_ncc_page_details`
  ADD CONSTRAINT `FK_dam_core_ncc_page_details_dam_core_ncc_page_PageId` FOREIGN KEY (`PageId`) REFERENCES `dam_core_ncc_page` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_page_details_history`
--
ALTER TABLE `dam_core_ncc_page_details_history`
  ADD CONSTRAINT `FK_dam_core_ncc_page_details_history_dam_core_ncc_page_details_h` FOREIGN KEY (`PageHistoryId`) REFERENCES `dam_core_ncc_page_details_history` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_page_history`
--
ALTER TABLE `dam_core_ncc_page_history`
  ADD CONSTRAINT `FK_dam_core_ncc_page_history_dam_core_ncc_page_ParentId` FOREIGN KEY (`ParentId`) REFERENCES `dam_core_ncc_page` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_permission_details`
--
ALTER TABLE `dam_core_ncc_permission_details`
  ADD CONSTRAINT `FK_dam_core_ncc_permission_details_dam_core_ncc_permission_Permi` FOREIGN KEY (`PermissionId`) REFERENCES `dam_core_ncc_permission` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_dam_core_ncc_permission_details_dam_core_ncc_user_ExtraAllowU` FOREIGN KEY (`ExtraAllowUserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_dam_core_ncc_permission_details_dam_core_ncc_user_ExtraDenyUs` FOREIGN KEY (`ExtraDenyUserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_post`
--
ALTER TABLE `dam_core_ncc_post`
  ADD CONSTRAINT `FK_dam_core_ncc_post_dam_core_ncc_post_ParentId` FOREIGN KEY (`ParentId`) REFERENCES `dam_core_ncc_post` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_dam_core_ncc_post_dam_core_ncc_user_AuthorId` FOREIGN KEY (`AuthorId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_post_category`
--
ALTER TABLE `dam_core_ncc_post_category`
  ADD CONSTRAINT `FK_dam_core_ncc_post_category_dam_core_ncc_category_CategoryId` FOREIGN KEY (`CategoryId`) REFERENCES `dam_core_ncc_category` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_dam_core_ncc_post_category_dam_core_ncc_post_PostId` FOREIGN KEY (`PostId`) REFERENCES `dam_core_ncc_post` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `dam_core_ncc_post_details`
--
ALTER TABLE `dam_core_ncc_post_details`
  ADD CONSTRAINT `FK_dam_core_ncc_post_details_dam_core_ncc_post_PostId` FOREIGN KEY (`PostId`) REFERENCES `dam_core_ncc_post` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_post_tag`
--
ALTER TABLE `dam_core_ncc_post_tag`
  ADD CONSTRAINT `FK_dam_core_ncc_post_tag_dam_core_ncc_post_PostId` FOREIGN KEY (`PostId`) REFERENCES `dam_core_ncc_post` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_dam_core_ncc_post_tag_dam_core_ncc_tag_TagId` FOREIGN KEY (`TagId`) REFERENCES `dam_core_ncc_tag` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `dam_core_ncc_startup`
--
ALTER TABLE `dam_core_ncc_startup`
  ADD CONSTRAINT `FK_dam_core_ncc_startup_dam_core_ncc_permission_PermissionId` FOREIGN KEY (`PermissionId`) REFERENCES `dam_core_ncc_permission` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_user_permission`
--
ALTER TABLE `dam_core_ncc_user_permission`
  ADD CONSTRAINT `FK_dam_core_ncc_user_permission_dam_core_ncc_permission_Permissi` FOREIGN KEY (`PermissionId`) REFERENCES `dam_core_ncc_permission` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_dam_core_ncc_user_permission_dam_core_ncc_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `dam_core_ncc_user_role`
--
ALTER TABLE `dam_core_ncc_user_role`
  ADD CONSTRAINT `FK_dam_core_ncc_user_role_dam_core_ncc_role_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `dam_core_ncc_role` (`Id`) ON DELETE CASCADE,
  ADD CONSTRAINT `FK_dam_core_ncc_user_role_dam_core_ncc_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `dam_core_ncc_web_site_info`
--
ALTER TABLE `dam_core_ncc_web_site_info`
  ADD CONSTRAINT `FK_dam_core_ncc_web_site_info_dam_core_ncc_web_site_NccWebSiteId` FOREIGN KEY (`NccWebSiteId`) REFERENCES `dam_core_ncc_web_site` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_web_site_widget`
--
ALTER TABLE `dam_core_ncc_web_site_widget`
  ADD CONSTRAINT `FK_dam_core_ncc_web_site_widget_dam_core_ncc_web_site_WebSiteId` FOREIGN KEY (`WebSiteId`) REFERENCES `dam_core_ncc_web_site` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_core_ncc_widget`
--
ALTER TABLE `dam_core_ncc_widget`
  ADD CONSTRAINT `FK_dam_core_ncc_widget_dam_core_ncc_plugins_NccPluginsId` FOREIGN KEY (`NccPluginsId`) REFERENCES `dam_core_ncc_plugins` (`Id`) ON DELETE NO ACTION;

--
-- Constraints for table `dam_ef_identity_role_claim_1`
--
ALTER TABLE `dam_ef_identity_role_claim_1`
  ADD CONSTRAINT `FK_dam_ef_identity_role_claim_1_dam_core_ncc_role_RoleId` FOREIGN KEY (`RoleId`) REFERENCES `dam_core_ncc_role` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `dam_ef_identity_user_claim_1`
--
ALTER TABLE `dam_ef_identity_user_claim_1`
  ADD CONSTRAINT `FK_dam_ef_identity_user_claim_1_dam_core_ncc_user_NccUserId` FOREIGN KEY (`NccUserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_dam_ef_identity_user_claim_1_dam_core_ncc_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `dam_ef_identity_user_login_1`
--
ALTER TABLE `dam_ef_identity_user_login_1`
  ADD CONSTRAINT `FK_dam_ef_identity_user_login_1_dam_core_ncc_user_NccUserId` FOREIGN KEY (`NccUserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE NO ACTION,
  ADD CONSTRAINT `FK_dam_ef_identity_user_login_1_dam_core_ncc_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE CASCADE;

--
-- Constraints for table `dam_ef_identity_user_token_1`
--
ALTER TABLE `dam_ef_identity_user_token_1`
  ADD CONSTRAINT `FK_dam_ef_identity_user_token_1_dam_core_ncc_user_UserId` FOREIGN KEY (`UserId`) REFERENCES `dam_core_ncc_user` (`Id`) ON DELETE CASCADE;
