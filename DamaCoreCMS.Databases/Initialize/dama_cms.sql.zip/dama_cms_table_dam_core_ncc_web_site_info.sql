
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_web_site_info`
--

CREATE TABLE `dam_core_ncc_web_site_info` (
  `Id` bigint(20) NOT NULL,
  `Copyrights` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `FaviconUrl` longtext,
  `Language` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `NccWebSiteId` bigint(20) DEFAULT NULL,
  `PrivacyPolicyUrl` longtext,
  `SiteLogoUrl` longtext,
  `SiteTitle` longtext,
  `Status` int(11) NOT NULL,
  `Tagline` longtext,
  `TermsAndConditionsUrl` longtext,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_web_site_info`
--

INSERT INTO `dam_core_ncc_web_site_info` (`Id`, `Copyrights`, `CreateBy`, `CreationDate`, `FaviconUrl`, `Language`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `NccWebSiteId`, `PrivacyPolicyUrl`, `SiteLogoUrl`, `SiteTitle`, `Status`, `Tagline`, `TermsAndConditionsUrl`, `VersionNumber`) VALUES
(1, NULL, 0, '2018-09-07 15:34:44.113052', NULL, 'en', '', '2018-09-07 15:34:44.113054', 0, 'Damara', 1, NULL, NULL, 'Damara', 0, 'Website tag line', NULL, 1),
(2, NULL, 0, '2018-09-07 15:34:44.113735', NULL, 'bn', '', '2018-09-07 15:34:44.113736', 0, 'Damara', 1, NULL, NULL, 'Damara', 0, 'Website tag line', NULL, 1);
