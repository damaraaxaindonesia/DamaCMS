
-- --------------------------------------------------------

--
-- Table structure for table `dam_ef_identity_user_login_1`
--

CREATE TABLE `dam_ef_identity_user_login_1` (
  `LoginProvider` varchar(127) NOT NULL,
  `ProviderKey` varchar(127) NOT NULL,
  `NccUserId` bigint(20) DEFAULT NULL,
  `ProviderDisplayName` longtext,
  `UserId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
