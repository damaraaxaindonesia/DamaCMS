
-- --------------------------------------------------------

--
-- Table structure for table `dam_ef_migration_history`
--

CREATE TABLE `dam_ef_migration_history` (
  `MigrationId` varchar(95) NOT NULL,
  `ProductVersion` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_ef_migration_history`
--

INSERT INTO `dam_ef_migration_history` (`MigrationId`, `ProductVersion`) VALUES
('20171205132842_InitMySql', '2.0.1-rtm-125');
