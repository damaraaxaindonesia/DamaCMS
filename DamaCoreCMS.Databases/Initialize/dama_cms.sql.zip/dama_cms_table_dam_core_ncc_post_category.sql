
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_post_category`
--

CREATE TABLE `dam_core_ncc_post_category` (
  `PostId` bigint(20) NOT NULL,
  `CategoryId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_post_category`
--

INSERT INTO `dam_core_ncc_post_category` (`PostId`, `CategoryId`) VALUES
(1, 1);
