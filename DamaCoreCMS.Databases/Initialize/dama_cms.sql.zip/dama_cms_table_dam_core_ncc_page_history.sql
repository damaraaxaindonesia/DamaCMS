
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_page_history`
--

CREATE TABLE `dam_core_ncc_page_history` (
  `Id` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Layout` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `PageId` bigint(20) NOT NULL,
  `PageOrder` int(11) NOT NULL,
  `PageStatus` int(11) NOT NULL,
  `PageType` int(11) NOT NULL,
  `ParentId` bigint(20) DEFAULT NULL,
  `PublishDate` datetime(6) NOT NULL,
  `Status` int(11) NOT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
