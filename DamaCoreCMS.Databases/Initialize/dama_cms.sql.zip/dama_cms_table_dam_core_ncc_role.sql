
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_role`
--

CREATE TABLE `dam_core_ncc_role` (
  `Id` bigint(20) NOT NULL,
  `ConcurrencyStamp` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` varchar(256) DEFAULT NULL,
  `NormalizedName` varchar(256) DEFAULT NULL,
  `Slug` longtext,
  `Status` int(11) NOT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_role`
--

INSERT INTO `dam_core_ncc_role` (`Id`, `ConcurrencyStamp`, `CreateBy`, `CreationDate`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `NormalizedName`, `Slug`, `Status`, `VersionNumber`) VALUES
(1, '797e0c13-b171-464a-8a11-64de8f4a81a6', 0, '2018-09-07 15:34:43.282591', NULL, '2018-09-07 15:34:43.282747', 0, 'SuperAdmin', 'SUPERADMIN', NULL, 0, 0);
