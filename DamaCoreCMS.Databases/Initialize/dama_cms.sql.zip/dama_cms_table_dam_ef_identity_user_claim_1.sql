
-- --------------------------------------------------------

--
-- Table structure for table `dam_ef_identity_user_claim_1`
--

CREATE TABLE `dam_ef_identity_user_claim_1` (
  `Id` int(11) NOT NULL,
  `ClaimType` longtext,
  `ClaimValue` longtext,
  `NccUserId` bigint(20) DEFAULT NULL,
  `UserId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
