
DELIMITER $$
--
-- Procedures
--
CREATE DEFINER=`root`@`localhost` PROCEDURE `proc_test` ()  BEGIN

END$$

DELIMITER ;
