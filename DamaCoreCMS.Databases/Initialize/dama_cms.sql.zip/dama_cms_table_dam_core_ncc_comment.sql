
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_comment`
--

CREATE TABLE `dam_core_ncc_comment` (
  `Id` bigint(20) NOT NULL,
  `AuthorId` bigint(20) DEFAULT NULL,
  `AuthorName` longtext,
  `CommentStatus` int(11) NOT NULL,
  `Content` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Email` longtext,
  `Metadata` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `PostId` bigint(20) DEFAULT NULL,
  `Status` int(11) NOT NULL,
  `Title` longtext,
  `VersionNumber` int(11) NOT NULL,
  `WebSite` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_comment`
--

INSERT INTO `dam_core_ncc_comment` (`Id`, `AuthorId`, `AuthorName`, `CommentStatus`, `Content`, `CreateBy`, `CreationDate`, `Email`, `Metadata`, `ModificationDate`, `ModifyBy`, `Name`, `PostId`, `Status`, `Title`, `VersionNumber`, `WebSite`) VALUES
(1, NULL, NULL, 1, 'This is a sample comment.', 0, '2018-09-07 15:34:46.231850', NULL, 'DEMODATA', '2018-09-07 15:34:46.231850', 0, 'Sample Comments', 1, 0, NULL, 1, NULL);
