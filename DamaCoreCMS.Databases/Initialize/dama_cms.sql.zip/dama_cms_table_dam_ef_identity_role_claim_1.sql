
-- --------------------------------------------------------

--
-- Table structure for table `dam_ef_identity_role_claim_1`
--

CREATE TABLE `dam_ef_identity_role_claim_1` (
  `Id` int(11) NOT NULL,
  `ClaimType` longtext,
  `ClaimValue` longtext,
  `RoleId` bigint(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
