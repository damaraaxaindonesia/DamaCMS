
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_user`
--

CREATE TABLE `dam_core_ncc_user` (
  `Id` bigint(20) NOT NULL,
  `AccessFailedCount` int(11) NOT NULL,
  `ConcurrencyStamp` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Email` varchar(256) DEFAULT NULL,
  `EmailConfirmed` bit(1) NOT NULL,
  `FullName` longtext,
  `LockoutEnabled` bit(1) NOT NULL,
  `LockoutEnd` datetime(6) DEFAULT NULL,
  `Metadata` longtext,
  `Mobile` longtext,
  `IsRequireLogin` bit(1) NOT NULL DEFAULT b'0',
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `Name` longtext,
  `NormalizedEmail` varchar(256) DEFAULT NULL,
  `NormalizedUserName` varchar(256) DEFAULT NULL,
  `PasswordHash` longtext,
  `PhoneNumber` longtext,
  `PhoneNumberConfirmed` bit(1) NOT NULL,
  `SecurityStamp` longtext,
  `Slug` longtext,
  `Status` int(11) NOT NULL,
  `TwoFactorEnabled` bit(1) NOT NULL,
  `UserName` varchar(256) DEFAULT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_user`
--

INSERT INTO `dam_core_ncc_user` (`Id`, `AccessFailedCount`, `ConcurrencyStamp`, `CreateBy`, `CreationDate`, `Email`, `EmailConfirmed`, `FullName`, `LockoutEnabled`, `LockoutEnd`, `Metadata`, `Mobile`, `IsRequireLogin`, `ModificationDate`, `ModifyBy`, `Name`, `NormalizedEmail`, `NormalizedUserName`, `PasswordHash`, `PhoneNumber`, `PhoneNumberConfirmed`, `SecurityStamp`, `Slug`, `Status`, `TwoFactorEnabled`, `UserName`, `VersionNumber`) VALUES
(1, 0, '04d73e0f-c55f-456f-a3ec-a0922ec32888', 0, '2018-09-07 15:34:43.704315', 'admin@yourdomain.com', b'0', 'Site Super Admin', b'1', NULL, NULL, NULL, b'0', '2018-09-07 17:04:53.215035', 0, 'Super Admin', 'ADMIN@YOURDOMAIN.COM', 'ADMIN', 'AQAAAAEAACcQAAAAEPmTHC73dzpDvZ7KwhOrfXdL4PalFhqgd8Czxnpx/g0+RT2nlUqP0S3xxK/z7t1AfQ==', NULL, b'0', 'f2b49bbb-797a-478d-93ae-97da8f0806b1', NULL, 0, b'0', 'Admin', 1);
