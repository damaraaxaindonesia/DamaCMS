
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_module_dependency`
--

CREATE TABLE `dam_core_ncc_module_dependency` (
  `Id` bigint(20) NOT NULL,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Metadata` longtext,
  `ModuleVersion` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `ModuleName` longtext,
  `Name` longtext,
  `NccModuleId` bigint(20) DEFAULT NULL,
  `Status` int(11) NOT NULL,
  `VersionNumber` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
