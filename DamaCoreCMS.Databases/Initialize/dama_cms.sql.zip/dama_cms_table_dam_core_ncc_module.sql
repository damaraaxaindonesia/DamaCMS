
-- --------------------------------------------------------

--
-- Table structure for table `dam_core_ncc_module`
--

CREATE TABLE `dam_core_ncc_module` (
  `Id` bigint(20) NOT NULL,
  `ExecutionOrder` int(11) NOT NULL DEFAULT '100',
  `AntiForgery` bit(1) NOT NULL,
  `Author` longtext,
  `Category` longtext,
  `CreateBy` bigint(20) NOT NULL,
  `CreationDate` datetime(6) NOT NULL,
  `Description` longtext,
  `Folder` longtext,
  `IsCore` bit(1) NOT NULL,
  `Metadata` longtext,
  `NccVersion` longtext,
  `ModificationDate` datetime(6) NOT NULL,
  `ModifyBy` bigint(20) NOT NULL,
  `ModuleName` longtext,
  `ModuleStatus` int(11) NOT NULL,
  `ModuleTitle` longtext,
  `Name` longtext,
  `Path` longtext,
  `Status` int(11) NOT NULL,
  `Version` longtext,
  `VersionNumber` int(11) NOT NULL,
  `WebSite` longtext
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dam_core_ncc_module`
--

INSERT INTO `dam_core_ncc_module` (`Id`, `ExecutionOrder`, `AntiForgery`, `Author`, `Category`, `CreateBy`, `CreationDate`, `Description`, `Folder`, `IsCore`, `Metadata`, `NccVersion`, `ModificationDate`, `ModifyBy`, `ModuleName`, `ModuleStatus`, `ModuleTitle`, `Name`, `Path`, `Status`, `Version`, `VersionNumber`, `WebSite`) VALUES
(1, 100, b'1', 'DamaCoreCMS', 'Core', 0, '2018-09-07 15:38:24.859194', 'Builtin Administration for Content Management.', 'Core.Admin', b'1', '', '0.4.5', '2018-09-07 15:38:24.859194', 0, 'Core.Admin', 3, 'CMS Administration', 'Core.Admin', 'D:\\proyek\\NetCoreCMS-master\\NetCoreCMS.Web\\Core\\Core.Admin', 0, '0.1.1', 1, 'http://DotNetCoreCMS.com'),
(2, 100, b'1', 'DamaCoreCMS', 'Core', 0, '2018-09-07 15:38:25.190587', 'Builtin Blog Module.', 'Core.Blog', b'1', '', '0.4.5', '2018-09-07 15:38:25.190587', 0, 'Core.Blog', 3, 'Blog', 'Core.Blog', 'D:\\proyek\\NetCoreCMS-master\\NetCoreCMS.Web\\Core\\Core.Blog', 0, '0.1.1', 1, 'http://DotNetCoreCMS.com'),
(3, 100, b'1', 'DamaCoreCMS', 'Core', 0, '2018-09-07 15:38:25.282031', 'Builtin Content Management System Module.', 'Core.Cms', b'1', '', '0.4.5', '2018-09-07 15:38:25.282031', 0, 'Core.Cms', 3, 'CMS', 'Core.Cms', 'D:\\proyek\\NetCoreCMS-master\\NetCoreCMS.Web\\Core\\Core.Cms', 0, '0.1.1', 1, 'http://DotNetCoreCMS.com'),
(4, 100, b'1', 'DamaCoreCMS', 'Core', 0, '2018-09-07 15:38:25.367414', 'Builtin Media module for Content Management.', 'Core.Media', b'1', '', '0.4.5', '2018-09-07 15:38:25.367414', 0, 'Core.Media', 3, 'CMS Media', 'Core.Media', 'D:\\proyek\\NetCoreCMS-master\\NetCoreCMS.Web\\Core\\Core.Media', 0, '0.1.1', 1, 'http://DotNetCoreCMS.com'),
(9, 100, b'1', 'DamaCoreCMS', 'Demo, data', 0, '2018-09-10 02:38:40.343098', 'Builtin Demo data for page and blog Module.', 'DamaCoreCMS.DemoData', b'0', '', '0.4.5', '2018-09-10 02:38:40.343098', 0, 'DamaCoreCMS.DemoData', 0, 'Demo Data', 'DamaCoreCMS.DemoData', 'D:\\proyek\\dama-cms\\DamaCoreCMS.Web\\Modules\\DamaCoreCMS.DemoData', 0, '0.1.1', 1, 'http://DotNetCoreCMS.com'),
(10, 100, b'1', 'DamaCoreCMS', 'Link,share,notice,News', 0, '2018-09-10 02:38:41.212988', 'Easy and smart News Module.', 'DamaCoreCMS.EasyNews', b'0', '', '0.4.5', '2018-09-10 02:38:41.212988', 0, 'DamaCoreCMS.EasyNews', 0, 'Easy News', 'DamaCoreCMS.EasyNews', 'D:\\proyek\\dama-cms\\DamaCoreCMS.Web\\Modules\\DamaCoreCMS.EasyNews', 0, '1.1', 1, 'http://DotNetCoreCMS.com'),
(11, 100, b'1', 'DamaCoreCMS', 'HelloWorld,Example', 0, '2018-09-10 02:38:41.289023', 'Builtin Content Management Example Module.', 'DamaCoreCMS.HelloWorld', b'0', '', '0.4.5', '2018-09-10 02:38:41.289023', 0, 'DamaCoreCMS.HelloWorld', 0, 'NetCoreCMS HelloWorld', 'DamaCoreCMS.HelloWorld', 'D:\\proyek\\dama-cms\\DamaCoreCMS.Web\\Modules\\DamaCoreCMS.HelloWorld', 0, '0.1.1', 1, 'http://DotNetCoreCMS.com'),
(12, 100, b'1', 'DamaCoreCMS', 'Image,Slider,Media', 0, '2018-09-10 02:38:41.366913', 'Builtin ImageSlider Module.', 'DamaCoreCMS.ImageSlider', b'0', '', '0.4.5', '2018-09-10 02:38:41.366913', 0, 'DamaCoreCMS.ImageSlider', 0, 'Image Slider', 'DamaCoreCMS.ImageSlider', 'D:\\proyek\\dama-cms\\DamaCoreCMS.Web\\Modules\\DamaCoreCMS.ImageSlider', 0, '1.0', 1, 'http://DotNetCoreCMS.com');
